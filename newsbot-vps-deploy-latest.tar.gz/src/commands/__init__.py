# =============================================================================
# NewsBot Commands Package
# =============================================================================
# Command modules for the NewsBot - each module should have a register(bot) function
# Last updated: 2025-01-16
