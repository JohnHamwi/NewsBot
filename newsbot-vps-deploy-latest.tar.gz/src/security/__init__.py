# =============================================================================
# NewsBot Security Package
# =============================================================================
# Security components including role-based access control (RBAC)
# Last updated: 2025-01-16
