# =============================================================================
# NewsBot Core Package
# =============================================================================
# Core components and configuration management for the NewsBot Discord bot
# Last updated: 2025-01-16
