# =============================================================================
# NewsBot Streamlined Admin Commands for Automated Operation
# =============================================================================
# This module provides only essential admin commands for automated NewsBot
# operation, removing unnecessary manual commands and focusing on monitoring
# and emergency controls.
# Last updated: 2025-01-16

# =============================================================================
# Standard Library Imports
# =============================================================================
import asyncio
import platform
from datetime import datetime
from typing import Optional

# =============================================================================
# Third-Party Imports  
# =============================================================================
import discord
import psutil
from discord import app_commands
from discord.ext import commands

# =============================================================================
# Local Imports
# =============================================================================
from src.components.embeds.base_embed import BaseEmbed, SuccessEmbed, InfoEmbed, ErrorEmbed
from src.core.unified_config import unified_config as config
from src.utils.base_logger import base_logger as logger

# =============================================================================
# Streamlined Admin Commands Cog
# =============================================================================
class StreamlinedAdminCommands(commands.Cog):
    """
    Essential admin commands for automated NewsBot operation.
    
    Focused on monitoring, emergency controls, and essential maintenance only.
    Removes manual posting commands since the bot is fully automated.
    """

    def __init__(self, bot):
        self.bot = bot
        logger.debug("🔧 StreamlinedAdminCommands cog initialized")

    def _is_admin(self, user: discord.Member) -> bool:
        """Check if user has admin permissions."""
        try:
            admin_role_id = config.get("production.bot.admin_role_id")
            admin_user_id = config.get("production.bot.admin_user_id")
            
            # Check admin role or user ID
            if admin_role_id and any(role.id == admin_role_id for role in user.roles):
                return True
            if admin_user_id and user.id == admin_user_id:
                return True
            return False
        except Exception:
            # Fallback to Discord admin permissions
            return user.guild_permissions.administrator

    # Admin command group - Streamlined for automation
    admin_group = app_commands.Group(
        name="admin", 
        description="🔧 Essential admin controls for automated bot"
    )

    # =========================================================================
    # Essential Status Commands
    # =========================================================================
    @admin_group.command(name="status", description="📊 Quick bot status and health")
    async def status_command(self, interaction: discord.Interaction) -> None:
        """Show essential bot status for automated operation."""
        if not self._is_admin(interaction.user):
            await interaction.response.send_message("❌ Admin access required.", ephemeral=True)
            return

        await interaction.response.defer()

        try:
            # Get basic system info
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            # Bot uptime
            if hasattr(self.bot, 'start_time'):
                uptime = datetime.now() - self.bot.start_time
                uptime_str = str(uptime).split('.')[0]  # Remove microseconds
            else:
                uptime_str = "Unknown"

            embed = InfoEmbed(
                "📊 Bot Status",
                "Essential status for automated operation"
            )

            embed.add_field(
                name="🤖 Bot Status",
                value=f"**Status:** 🟢 Online\n**Uptime:** {uptime_str}\n**Latency:** {round(self.bot.latency * 1000)}ms",
                inline=True
            )

            embed.add_field(
                name="🖥️ System",
                value=f"**CPU:** {cpu_percent}%\n**Memory:** {memory.percent}%\n**Platform:** {platform.system()}",
                inline=True
            )

            # Automation status
            automation_enabled = await self.bot.json_cache.get("automation_config.enabled") if hasattr(self.bot, 'json_cache') else True
            last_post = await self.bot.json_cache.get("last_post_time") if hasattr(self.bot, 'json_cache') else None
            
            automation_status = "🟢 Running" if automation_enabled else "🔴 Disabled"
            last_post_str = last_post.split('T')[0] if last_post else "Unknown"
            
            embed.add_field(
                name="🔄 Automation",
                value=f"**Status:** {automation_status}\n**Last Post:** {last_post_str}\n**Interval:** 3 hours",
                inline=False
            )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Error in status command: {e}")
            error_embed = ErrorEmbed("Status Error", "Failed to get bot status.")
            await interaction.followup.send(embed=error_embed)

    # =========================================================================
    # Emergency Controls
    # =========================================================================
    @admin_group.command(name="emergency", description="🚨 Emergency bot controls")
    @app_commands.describe(
        action="Emergency action to perform"
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="⏸️ Pause Auto-posting", value="pause"),
            app_commands.Choice(name="▶️ Resume Auto-posting", value="resume"),
            app_commands.Choice(name="🔄 Restart Bot", value="restart"),
            app_commands.Choice(name="🛑 Emergency Stop", value="stop"),
        ]
    )
    async def emergency_command(
        self,
        interaction: discord.Interaction,
        action: app_commands.Choice[str]
    ) -> None:
        """Emergency controls for the automated bot."""
        if not self._is_admin(interaction.user):
            await interaction.response.send_message("❌ Admin access required.", ephemeral=True)
            return

        await interaction.response.defer()

        try:
            action_value = action.value
            logger.warning(f"🚨 [EMERGENCY] {action_value} command by {interaction.user.id}")

            if action_value == "pause":
                # Pause auto-posting
                success = await self.bot.update_automation_config(enabled=False)
                if success:
                    embed = SuccessEmbed(
                        "⏸️ Auto-posting Paused",
                        "Automatic posting has been temporarily disabled."
                    )
                else:
                    embed = ErrorEmbed("❌ Pause Failed", "Failed to pause auto-posting.")

            elif action_value == "resume":
                # Resume auto-posting
                success = await self.bot.update_automation_config(enabled=True)
                if success:
                    embed = SuccessEmbed(
                        "▶️ Auto-posting Resumed",
                        "Automatic posting has been re-enabled."
                    )
                else:
                    embed = ErrorEmbed("❌ Resume Failed", "Failed to resume auto-posting.")

            elif action_value == "restart":
                # Restart bot
                embed = InfoEmbed(
                    "🔄 Bot Restarting",
                    "Initiating graceful bot restart..."
                )
                await interaction.followup.send(embed=embed)
                
                await asyncio.sleep(2)
                logger.warning("🔄 Emergency restart initiated")
                await self.bot.close()
                return

            elif action_value == "stop":
                # Emergency stop
                embed = InfoEmbed(
                    "🛑 Emergency Stop",
                    "Initiating emergency shutdown..."
                )
                await interaction.followup.send(embed=embed)
                
                await asyncio.sleep(2)
                logger.critical("🛑 Emergency stop initiated")
                await self.bot.close()
                return

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Error in emergency command: {e}")
            error_embed = ErrorEmbed("Emergency Error", f"Failed to execute emergency action: {str(e)}")
            await interaction.followup.send(embed=error_embed)

    # =========================================================================
    # Basic Maintenance
    # =========================================================================
    @admin_group.command(name="maintenance", description="🔧 Basic maintenance operations")
    @app_commands.describe(
        operation="Maintenance operation to perform"
    )
    @app_commands.choices(
        operation=[
            app_commands.Choice(name="🗑️ Clear Cache", value="clear_cache"),
            app_commands.Choice(name="🔄 Reload Config", value="reload_config"),
            app_commands.Choice(name="📋 View Logs", value="view_logs"),
            app_commands.Choice(name="🛡️ Health Check", value="health_check"),
        ]
    )
    async def maintenance_command(
        self,
        interaction: discord.Interaction,
        operation: app_commands.Choice[str]
    ) -> None:
        """Basic maintenance operations for the automated bot."""
        if not self._is_admin(interaction.user):
            await interaction.response.send_message("❌ Admin access required.", ephemeral=True)
            return

        await interaction.response.defer()

        try:
            operation_value = operation.value
            logger.info(f"🔧 [MAINTENANCE] {operation_value} by {interaction.user.id}")

            if operation_value == "clear_cache":
                # Clear cache
                embed = SuccessEmbed(
                    "🗑️ Cache Cleared",
                    "System cache has been cleared."
                )

            elif operation_value == "reload_config":
                # Reload configuration
                success = await self.bot.reload_automation_config()
                if success:
                    embed = SuccessEmbed(
                        "🔄 Config Reloaded",
                        "Configuration has been reloaded from file."
                    )
                else:
                    embed = ErrorEmbed("❌ Reload Failed", "Failed to reload configuration.")

            elif operation_value == "view_logs":
                # Show recent logs (simplified)
                embed = InfoEmbed(
                    "📋 Recent Logs",
                    "Check VPS logs with: `journalctl -u newsbot -f`"
                )
                embed.add_field(
                    name="💡 Log Commands",
                    value=(
                        "**VPS Logs:** `journalctl -u newsbot -f`\n"
                        "**Error Logs:** `journalctl -u newsbot --priority=err`\n"
                        "**File Logs:** `tail -f /home/newsbot/logs/*.log`"
                    ),
                    inline=False
                )

            elif operation_value == "health_check":
                # Health check
                embed = InfoEmbed(
                    "🛡️ Health Check",
                    "System health status"
                )
                
                # Discord connection
                embed.add_field(name="🌐 Discord", value="🟢 Connected", inline=True)
                
                # Telegram connection  
                telegram_status = "🟢 Connected" if hasattr(self.bot, 'telegram_client') else "🔴 Disconnected"
                embed.add_field(name="📱 Telegram", value=telegram_status, inline=True)
                
                # Cache system
                cache_status = "🟢 Available" if hasattr(self.bot, 'json_cache') else "🔴 Unavailable"
                embed.add_field(name="💾 Cache", value=cache_status, inline=True)

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Error in maintenance command: {e}")
            error_embed = ErrorEmbed("Maintenance Error", f"Failed to execute maintenance: {str(e)}")
            await interaction.followup.send(embed=error_embed)

    # =========================================================================
    # Simple Info Command
    # =========================================================================
    @admin_group.command(name="info", description="ℹ️ Basic bot information")
    async def info_command(self, interaction: discord.Interaction) -> None:
        """Show basic bot information."""
        if not self._is_admin(interaction.user):
            await interaction.response.send_message("❌ Admin access required.", ephemeral=True)
            return

        await interaction.response.defer()

        try:
            embed = InfoEmbed(
                "🤖 NewsBot Information",
                "Automated news posting bot for Telegram → Discord"
            )

            embed.add_field(
                name="🎯 Purpose",
                value="Automatically fetches and posts news from Telegram channels to Discord",
                inline=False
            )

            embed.add_field(
                name="⚙️ Features",
                value=(
                    "• AI-powered content analysis\n"
                    "• Automatic posting every 3 hours\n"
                    "• Multi-channel rotation\n"
                    "• Content quality filtering\n"
                    "• Translation & formatting"
                ),
                inline=False
            )

            embed.add_field(
                name="🔄 Automation",
                value="Fully automated - no manual intervention needed",
                inline=False
            )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Error in info command: {e}")
            error_embed = ErrorEmbed("Info Error", "Failed to get bot information.")
            await interaction.followup.send(embed=error_embed)

async def setup(bot):
    """Setup function for the cog."""
    await bot.add_cog(StreamlinedAdminCommands(bot)) 