# =============================================================================
# NewsBot Cache Package
# =============================================================================
# Caching implementations including JSON and Redis-based solutions
# Last updated: 2025-01-16
